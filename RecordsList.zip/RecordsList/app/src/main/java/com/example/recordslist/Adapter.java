package com.example.recordslist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
LayoutInflater inflater;
List<Records> records;

public Adapter(Context ctx, List<Records> records)
{
    this.inflater=LayoutInflater.from(ctx);
    this.records=records;
}
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = inflater.inflate(R.layout.custom__list_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
    //here we bind the data
        holder.name.setText(records.get(position).getName());
        holder.subjects.setText(records.get(position).getSubjects());
        holder.qualification.setText(records.get(position).getQualification());
        Picasso.get().load(records.get(position).getProfileImage()).into(holder.profileImage);

    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public static class ViewHolder extends  RecyclerView.ViewHolder{
    TextView name,subjects,qualification;
    ImageView profileImage;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            name =itemView.findViewById(R.id.name);
            subjects=itemView.findViewById(R.id.subjects);
            qualification=itemView.findViewById(R.id.qualification);
            profileImage=itemView.findViewById(R.id.profileImage);
        }
    }
}
