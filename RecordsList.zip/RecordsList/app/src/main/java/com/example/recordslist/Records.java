package com.example.recordslist;

public class Records {
    private String profileImage;
    private String name;
    private String subjects;
    private String qualification;

    public Records() { }
    public Records(String profileImage,String name,String subjects,String qualification)
    {
        this.profileImage=profileImage;
        this.name=name;
        this.name=name;
        this.subjects=subjects;
        this.qualification=qualification;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubjects() {
        return subjects;
    }

    public void setSubjects(String subjects) {
        this.subjects = subjects;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
}
